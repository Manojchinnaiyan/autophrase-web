import './assets/index.ts-DkiOyajX.js';
